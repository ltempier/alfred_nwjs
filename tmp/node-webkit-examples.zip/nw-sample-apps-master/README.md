# Sample apps for NW.js

Here are some sample apps for [nw.js](https://github.com/nwjs/nw.js),
some of them are modified from [GoogleChrome/chrome-app-samples](https://github.com/GoogleChrome/chrome-app-samples).

Please visit [nw.js group](http://groups.google.com/group/nwjs-general) for discussions.


## How to run apps

https://github.com/nwjs/nw.js/wiki/How-to-run-apps
