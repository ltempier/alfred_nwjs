## Custom tray menu

It shows custom menu when click tray icon.

**How to run:**

```
git clone git@github.com:zcbenz/nw-sample-apps.git
nw nw-sample-apps/custom-tray-menu
```

![custom-tray-menu screenshot](https://cloud.githubusercontent.com/assets/26019/7777492/b46bd738-00ed-11e5-8e9b-45d981cc4b0c.png)


## APIs

* [Tray](https://github.com/nwjs/nw.js/wiki/Tray)
* [Window](https://github.com/nwjs/nw.js/wiki/Window)
* [Screen](https://github.com/nwjs/nw.js/wiki/Screen)
