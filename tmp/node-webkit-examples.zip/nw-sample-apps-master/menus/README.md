# Menus

This is a basic demo that demonstrates the flexibility of node-webkit's Menus
API, there aree three menus bound to three areas in the page.

**This demo requires node-webkit >= v0.3.0.**

## APIs

* [Menu](https://github.com/nwjs/nw.js/wiki/Menu)
* [MenuItem](https://github.com/nwjs/nw.js/wiki/MenuItem)
